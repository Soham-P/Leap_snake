import sys
import Leap
import thread
import time
from Leap import *



class LeapMotionListener(Listener):
        finger_names = ['Thumb','Index','Middle','Ring','Pinky']
        bone_names = ['Metacarpal','Proximal','Intermediate','Distal']

        def on_init(self,controller):
                print "Initialized"

        def on_connect(self,controller):
                print "Motion sensor connected!"

        def on_disconnect(sef,controller):
                print "Motion disconnected"

        def on_exit(self,controller):
                print "Exited"


        def on_frame(self,controller):
                frame = controller.frame()
                for hand in frame.hands:
                        handType = "Left Hand" if  hand.is_left else "Right Hand"
                        if handType is "Left Hand":
                                print "left"
                        elif handType is "Right Hand":
                                print "right" 

# 			for finger in hand.fingers:
# 				fingers = self.finger_names[finger.type()]
# 				print fingers + str(fingers.length)
# ##				for b in range(0, 4):
# ##                  bone = finger.bone(b)
# ##                  print str(bone.direction)
                        
                        

        

def main():
        listener = LeapMotionListener()
        controller = Leap.Controller()
        controller.add_listener(listener)

print  "Press enter to quit"
try:
        sys.stdin.readline()
except KeyboardInterrupt:
        pass
finally:
        controller.remove_listener(listener)
if __name__ == "__main__":
        main()
