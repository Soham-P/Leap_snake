import Leap, sys, thread, time
from Leap import CircleGesture, KeyTapGesture, ScreenTapGesture, SwipeGesture

class LeapMotionListener(Leap.Listener):
    finger_names = ['Thumb', 'Index', 'Middle', 'Ring', 'Pinky']
    bone_names = ['Metacarpal', 'Proxima', 'Intermediate', 'Distal']
    state_names = ['STATE_INVALID', 'STATE_START', 'STATE_UPDATE', 'STATE_END']

    def on_init(self, controller):
        print ("Listener Initialized!")

    def on_connect(self, controller):
        print ("Leap Motion Sensor Connected!")

        time.sleep(2)

        controller.enable_gesture(Leap.Gesture.TYPE_CIRCLE);
        controller.enable_gesture(Leap.Gesture.TYPE_KEY_TAB);
        controller.enable_gesture(Leap.Gesture.TYPE_SCREEN_TAP);
        controller.enable_gesture(Leap.Gesture.TYPE_SWIPE);

    def on_disconnect(self, controller):
        print ("Leap Motion Disconnected!")

    def on_exit(self, controller):
        print ("Leap Motion Exited")

    def on_frame(self, controller):
        """
        Leap Motion sends about 290 frames data per second
        This function gets called 290 times per second
        This function will have acces to the data of the frame
        We then tell the program what to do with the data from
        the frames.
        """
        #pass
        frame = controller.frame()

        """
        Now we will see what kind of data we can get from each frame.
        """
        """
        print ("Frame ID: ", str(frame.id) + " Timestamp: "+ str(frame.timestamp) + " # of Hands: "+ str(len(frame.hands)) + " # of Fingers: "+ str(len(frame.fingers)) + " # of Tools: "+str(len(frame.tools)) + " # of Gestures: "+ str(len(frame.gestures())))
        """
        """
        Now we will gather data from each hand on the frame, to work with each hand, we will
        use a for loop
        """
        for hand in frame.hands:
            handType = "Left Hand" if hand.is_left else "Right Hand"

            print handType , " Hand ID: " + str(hand.id) + " Palm Position: " + str(hand.palm_position)

            normal = hand.palm_normal
            direction = hand.direction
                
            # We use direction. for the yaw and pitch angle, and we use normal. for the roll angle
            print "Pitch: " + str(direction.pitch * Leap.RAD_TO_DEG) + " Roll: " + str(normal.roll * Leap.RAD_TO_DEG) \
                  + " Yaw: " + str(direction.yaw * Leap.RAD_TO_DEG)

            # Getting data from each arm(arm, hand, wrist, elbow)

            arm = hand.arm

            print "Arm Direction: " + str(arm.direction) + " Wrist Postion: " + str(arm.wrist_position) \
                  + " Elbow Postion: " + str(arm.elbow_position)

            # Getting data from each finger

            for finger in hand.fingers:
                print "Finger Type: " + self.finger_names[finger.type()] \
                      + " Finger ID: " + str(finger.id) + " Lenght (mm): " + str(finger.lenght) \
                      + " Width (mm): ", + str(finger.width)
                
                # Getting data for each bone.

                for bones in range(0, 4): # there is 4, because there is only 4 bones in a finger
                    bone = finger.bone(bones)
                    print  "Bone: " + self.bones_names[bone.type] \
                          + " Start: " + str(bone.prev_joint) + " End: " + str(bone.next_join) + "Direction: " + str(bone.direction)
            
        # Now we will get the data for a tool

        for tool in frame.tools:
            print "Tool ID: " + str(tool.id) + " Tip Postion: " + str(tool.tip_position) + " Tool Direction: " + str(tool.direction)

        for gesture in frame.gestures():
            if gesture.type == Leap.Gesture.TYPE_CIRCLE:2
            circle = CircleGesture(gesture)

            if circle.pointable.direction.angle_to(circle.normal) <= Leap.PI/2:
                clockwiseness = "clockwise"
            else:
                clockwiseness = "anti clockwise"

            swept_angle = 0
            if circle.state != Leap.Gesture.STATE_START:
                previous = CircleGesture(controller.frame(1).gesture(circle.id)
                swept_angle = (circle.progress - previous.progress) * 2 * Leap.PI

            print "ID: " + str(circle.id) + " Progress: " + str(circle.progress) + " Radius: " + str(circle.radius) \
                    + " Swetp Angle: " + str(swept_angle * Leap.RAD_TO_DEG) + clockwiseness

def main():
    listener = LeapMotionListener()
    controller = Leap.Controller()

    controller.add_listener(listener)

    print ("Press 'Enter' to quit.")
    
    try:
        sys.stdin.readline()
    except KeyboardInterrupt:
        pass
    finally:
        controller.remove_listener(listener)
    
if __name__ == "__main__":
    main()
      







