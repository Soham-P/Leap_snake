# Libaries/ Modules

import Leap, sys, thread, time
from Leap import CircleGesture, KeyTapGesture, ScreenTapGesture, SwipeGesture

class LeapMotionListener(Leap.Listener):
    finger_names = ['Thumb', 'Index', 'Middle', 'Ring', 'Pinky']
    bone_names = ['Metacarpal', 'Proxima', 'Intermediate', 'Distal']
    state_names = ['STATE_INVALID', 'STATE_START', 'STATE_UPDATE', 'STATE_END']

    def on_init(self, controller):
        print ("Listener Initialized!")

    def on_connect(self, controller):
        print ("Leap Motion Sensor Connected!")

        #time.sleep(2)

        controller.enable_gesture(Leap.Gesture.TYPE_CIRCLE);
        #controller.enable_gesture(Leap.Gesture.TYPE_KEY_TAB);
        #controller.enable_gesture(Leap.Gesture.TYPE_SCREEN_TAP);
        #controller.enable_gesture(Leap.Gesture.TYPE_SWIPE);

    def on_disconnect(self, controller):
        print ("Leap Motion Disconnected!")

    def on_exit(self, controller):
        print ("Leap Motion Exited")

    def on_frame(self, controller):
        """
        Leap Motion sends about 290 frames data per second
        This function gets called 290 times per second
        This function will have acces to the data of the frame
        We then tell the program what to do with the data from
        the frames.
        """
        #pass
        frame = controller.frame()

        """
        Now we will see what kind of data we can get from each frame.
        """

        #print ("Frame ID: ", str(frame.id) + " Timestamp: "+ str(frame.timestamp) + " # of Hands: "+ str(len(frame.hands)) + " # of Fingers: "+ str(len(frame.fingers)) + " # of Tools: "+str(len(frame.tools)) + " # of Gestures: "+ str(len(frame.gestures())))

        """
        Now we will gather data from each hand on the frame, to work with each hand, we will
        use a for loop
        """
        x = 0

        for hand in frame.hands:
            handType = "Left Hand" if hand.is_left else "Right Hand"

            if handType == "Right Hand":
                x = x + 1
            else:
                x = x - 1


            for gesture in frame.gestures():
                if gesture.type == Leap.Gesture.TYPE_CIRCLE:
                    circle = CircleGesture(gesture)
                    print x
                    break
                else:
                    continue

"""
            if circle.pointable.direction.angle_to(circle.normal) <= Leap.PI/2:
                clockwiseness = "clockwise"
                if clockwiseness == "clockwise":
                    print x
            else:
                clockwiseness = "anti clockwise"
                """


            #print "ID: " + str(circle.id) + " Progress: " + str(circle.progress) + " Radius: " + str(circle.radius) \
                    #+ " Swetp Angle: " + str(swept_angle * Leap.RAD_TO_DEG) + clockwiseness

def main():
    listener = LeapMotionListener()
    controller = Leap.Controller()

    controller.add_listener(listener)

    print ("Press 'Enter' to quit.")

    try:
        sys.stdin.readline()
    except KeyboardInterrupt:
        pass
    finally:
        controller.remove_listener(listener)

if __name__ == "__main__":
    main()






