#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Galaxy
#
# Created:     26/07/2014
# Copyright:   (c) Galaxy 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import Leap, time
from Leap import *

LEFT = 'left'
RIGHT = 'right'
UP = 'up'
DOWN = 'down'

class LeapMotionListener(Listener):
    #finger_names = ['Thumb','Index','Middle','Ring','Pinky']
    #bone_names = ['Metacarpal','Proximal','Intermediate','Distal']

    def on_init(self,controller):
        print('initialized')
        controller.enable_gesture(Leap.Gesture.TYPE_SWIPE)
        controller.config.set("Gesture.Swipe.MinLength",5.0)
        controller.config.set("Gestrue.Swipe.MinVelocity", 5)
        controller.config.save()

    def on_frame(self,controller):
        frame = controller.frame()
        for hand in frame.hands:
            direction = self.directionswipe(hand.direction)
            print (direction)
##        for gesture in frame.gestures():
##            if gesture.type == Leap.Gesture.TYPE_SWIPE: #grabs, and filters events so only swipes gets in
##                swipe = SwipeGesture(gesture)
##                direction = self.directionswipe(swipe.direction)
##                print (direction)


    def directionswipe(self,swiper):
        x = 0
        y = 1
        if abs(swiper[x]) > 0.5 or abs(swiper[y])> 0.5:
            if abs(swiper[x]) > abs(swiper[y]):#determine which is more dominant direction up/down, or left/right
                if swiper[x] > 0:
                    return RIGHT
                else:
                    return LEFT
            else:
                if swiper[y]>0:
                    return UP
                else:
                    return DOWN


# Create a controller
listener = LeapMotionListener()
controller = Leap.Controller()

# Have the sample listener receive events from the controller
controller.add_listener(listener)
while True:
    time.sleep(1)